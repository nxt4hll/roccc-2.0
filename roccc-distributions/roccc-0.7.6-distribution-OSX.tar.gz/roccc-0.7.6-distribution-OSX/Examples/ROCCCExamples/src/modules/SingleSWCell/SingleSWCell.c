// This module performs the operations of a single cell in a systolic
//  array or 2-D wavefront algorithm.  The example provided here is the
//  calculations necessary for a Smith-Waterman implementation.

typedef int ROCCC_int8 ;

void SingleSWCell(ROCCC_int8 S, ROCCC_int8 T,
                  ROCCC_int8 north, ROCCC_int8 northwest, ROCCC_int8 west,
                  ROCCC_int8& result)
{
  const int matchCost = 4 ;
  const int mismatchCost = 3 ;
  const int insertCost = 2 ;
  const int deleteCost = 1 ;

  ROCCC_int8 intermediate0 ;
  ROCCC_int8 intermediate1 ;


  if (S == T)
  {
    intermediate0 = northwest + matchCost ;
  }
  else
  {
    intermediate0 = northwest + mismatchCost ;
  }

  if (north + insertCost > west + deleteCost)
  {
    intermediate1 = north + insertCost ;
  }
  else
  {
    intermediate1 = west + deleteCost ;
  }

  if (intermediate0 > intermediate1)
  {
    result = intermediate0 ;
  }
  else
  {
    result = intermediate1 ;
  }
}
