// This code performs Sobel edge detection on a large 2-Dimensional image.
//  It does this by applying a mask to a 3x3 sliding window over the original
//  image.  The output is a black and white image which will only show the
//  edges present in the original image.

void Sobel(int** image, int maxDistance, int height, int width, int** output)
{
  const int black = 0x00ffffff ;
  const int white = 0x00000000 ;
  const int maskX[9] = 
    { 
      -1, 0, 1,
      -2, 0, 2,
      -1, 0, 1 
    } ;
  const int maskY[9] = 
    { 
      1,  2,  1,
      0,  0,  0, 
      -1, -2, -1
    } ;
	
  int i ;
  int j ;
  int x ;
  int y ;
  int sumSquared ;
  
  for(i = 0 ; i < height ; ++i)
  {
    for(j = 0 ; j < width ; ++j)
    {
      x = maskX[0] * image[i][j]   + 
	maskX[1] * image[i][j+1]   + 
	maskX[2] * image[i][j+2]   +
	maskX[3] * image[i+1][j]   + 
	maskX[4] * image[i+1][j+1] + 
	maskX[5] * image[i+1][j+2] +
	maskX[6] * image[i+2][j]   + 
	maskX[7] * image[i+2][j+1] + 
	maskX[8] * image[i+2][j+2] ;
      
      y = maskY[0] * image[i][j]   + 
	maskY[1] * image[i][j+1]   + 
	maskY[2] * image[i][j+2]   +
	maskY[3] * image[i+1][j]   + 
	maskY[4] * image[i+1][j+1] + 
	maskY[5] * image[i+1][j+2] +
	maskY[6] * image[i+2][j]   + 
	maskY[7] * image[i+2][j+1] + 
	maskY[8] * image[i+2][j+2] ;
      
      sumSquared = x * x + y * y ;
      
      if (sumSquared >= maxDistance)
	output[i][j] = black ;
      else
	output[i][j] = white ;			
    }
  }
}
