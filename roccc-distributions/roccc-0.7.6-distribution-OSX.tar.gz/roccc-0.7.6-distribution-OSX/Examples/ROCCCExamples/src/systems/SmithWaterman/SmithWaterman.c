// This code performs the Smith Waterman calculation on a large 2-Dimensional
//  array.  The Systolic Array generation optimization will transform this
//  code into hardware that takes a one dimensional stream instead of a two
//  dimensional input stream and outputs a one dimensional stream.  The
//  input stream should be the first row of the original 2-D array A and the
//  output stream is the last calculated row of A.

#include "roccc-library.h"

typedef int ROCCC_int8 ;

void SmithWaterman(ROCCC_int8** A, ROCCC_int8* T)
{
  const int S[10] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9 } ;
  ROCCC_int8 tmpResult ;
  int i ;
  int j ;

  L1: for(i = 0 ; i < 10 ; ++i)
  {
    for (j = 0 ; j < 10 ; ++j)
    {
      SingleSWCell(S[i], T[j], A[i-1][j], A[i-1][j-1], A[i][j-1], tmpResult) ;
      A[i][j] = tmpResult ;
    }
  }
}
