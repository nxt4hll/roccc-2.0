#include <convey/usr/cny_comp.h>
#include <assert.h>
#include <stdio.h>
typedef unsigned long long uint64 ;
extern long rocccCall() ;
void Stub(int* A, int N, int cumulative_init, int* sum_out)
{
	cny_image_t sig ;
	cny_image_t sig2 ;
	uint64 finalValue ;
	uint64* inputParameters ;
	uint64* outputParameters ;
	assert(cny$get_signature_fptr != NULL) ;
	assert(cny_cp_interleave() != CNY_MI_3131) ;
	assert(cny$cp_malloc_fptr != NULL) ;
	(*cny$get_signature_fptr)("PLACE_SIGNATURE_HERE", &sig, &sig2) ;
	inputParameters = (uint64*)(*cny$cp_malloc_fptr)(3*8) ;
	outputParameters = (uint64*)(*cny$cp_malloc_fptr)(1*8) ;
	inputParameters[0] = (uint64)A ;
	inputParameters[1] = (uint64)N ;
	inputParameters[2] = (uint64)cumulative_init ;
	finalValue = l_copcall_fmt(sig, rocccCall, "AA", inputParameters, outputParameters) ;
	*sum_out = outputParameters[0] ;
}
