// The code multiplies a 1xN vector to an NxN matrix, resulting in a
//  1xN output vector.

typedef int ROCCC_int64 ;

void VectorMatrixMultiplication(ROCCC_int64* vector, ROCCC_int64** matrix, int N, ROCCC_int64* result)
{
  int i;
  int j ;
  ROCCC_int64 currentProduct ;
  
  for(i = 0; i < N ; ++i)
  {
    for (j = 0 ; j < N ; ++j)
    {
      if (j == 0)
	{
	  currentProduct = 0 ;
	}
      currentProduct += vector[j] * matrix[j][i] ;
      result[i] = currentProduct ;
    }
  }
}
