// This code takes a 3x3 sliding window over a large 2-Dimensional array
//  and stores the maximum value of the window at each point to a 2-D output
//  array named "max."  This instantiates four copies of the MaxFilter
//  module that determines the maximum among three values.

#include "roccc-library.h"

void MaxFilterSystem(int** window, int height, int width, int** max)
{
  int i ;
  int j ;

  int maxCol1 ;
  int maxCol2 ;
  int maxCol3 ;

  int windowMax ;

  for (i = 0 ; i < height ; ++i)
  {
    for (j = 0 ; j < width ; ++j)
    {
      MaxFilter(window[i][j], window[i][j+1], window[i][j+2], maxCol1) ;
      MaxFilter(window[i+1][j], window[i+1][j+1], window[i+1][j+2], maxCol2) ;
      MaxFilter(window[i+2][j], window[i+2][j+1], window[i+2][j+2], maxCol3) ;

      MaxFilter(maxCol1, maxCol2, maxCol3, windowMax) ;
      max[i][j] = windowMax ;
    }
  }
}


