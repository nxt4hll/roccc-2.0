#include <convey/usr/cny_comp.h>
#include <assert.h>
#include <stdio.h>
typedef unsigned long long uint64 ;
extern long rocccCall() ;
void Stub(int* A, int* Out, int N, int* sorted1_moduleOut2_out, int* sorted2_moduleOut3_out, int* sorted3_moduleOut4_out, int* sorted5_moduleOut6_out, int* sorted6_moduleOut7_out, int* sorted7_moduleOut8_out, int* sorted8_moduleOut9_out)
{
	cny_image_t sig ;
	cny_image_t sig2 ;
	uint64 finalValue ;
	uint64* inputParameters ;
	uint64* outputParameters ;
	assert(cny$get_signature_fptr != NULL) ;
	assert(cny_cp_interleave() != CNY_MI_3131) ;
	assert(cny$cp_malloc_fptr != NULL) ;
	(*cny$get_signature_fptr)("PLACE_SIGNATURE_HERE", &sig, &sig2) ;
	inputParameters = (uint64*)(*cny$cp_malloc_fptr)(3*8) ;
	outputParameters = (uint64*)(*cny$cp_malloc_fptr)(7*8) ;
	inputParameters[0] = (uint64)A ;
	inputParameters[1] = (uint64)Out ;
	inputParameters[2] = (uint64)N ;
	finalValue = l_copcall_fmt(sig, rocccCall, "AA", inputParameters, outputParameters) ;
	*sorted1_moduleOut2_out = outputParameters[0] ;
	*sorted2_moduleOut3_out = outputParameters[1] ;
	*sorted3_moduleOut4_out = outputParameters[2] ;
	*sorted5_moduleOut6_out = outputParameters[3] ;
	*sorted6_moduleOut7_out = outputParameters[4] ;
	*sorted7_moduleOut8_out = outputParameters[5] ;
	*sorted8_moduleOut9_out = outputParameters[6] ;
}
