// This system takes a sliding window of size 8 over a large 1-Dimensional
//  array and returns a stream of values that are the median of each window.
//  In order to determine the median, we need to sort each window, which we
//  do by calling the BitonicSort module.  Once sorted, we choose the value
//  in the middle as our output.

#include "roccc-library.h"

void MedianFilter(int* A, int N, int* Out)
{
	int i;
	int sorted1 ;
	int sorted2 ;
	int sorted3 ;
	int sorted4 ;
	int sorted5 ;
	int sorted6 ;
	int sorted7 ;
	int sorted8 ;
	
	for(i = 0; i < N ; ++i)
	{
		BitonicSort8(A[i], A[i+1], A[i+2], A[i+3], A[i+4], A[i+5], A[i+6], A[i+7],
					 sorted1, sorted2, sorted3, sorted4, sorted5, sorted6, sorted7, sorted8) ;
		Out[i] = sorted4 ;
	}
}
