/*

  This file does a full FFT Butterfly operation using all of the previous
   modules (one stage in particular).
 
*/

#include "roccc-library.h"

void FullFFT()
{
  int A[100] ;
  int B[100] ;

  int i ;

  // The first stage output wires and the second stage input wires
  int internalWire0 ;
  int internalWire1 ;
  int internalWire2 ;
  int internalWire3 ;  
  int internalWire4 ;
  int internalWire5 ;
  int internalWire6 ;
  int internalWire7 ;
  int internalWire8 ;
  int internalWire9 ;
  int internalWire10 ;
  int internalWire11 ;
  int internalWire12 ;
  int internalWire13 ;  
  int internalWire14 ;
  int internalWire15 ;

  // The second stage output wires and the third stage input wires

  int internalWire16 ;
  int internalWire17 ;
  int internalWire18 ;
  int internalWire19 ;
  int internalWire20 ;
  int internalWire21 ;
  int internalWire22 ;
  int internalWire23 ;  
  int internalWire24 ;
  int internalWire25 ;
  int internalWire26 ;
  int internalWire27 ;
  int internalWire28 ;
  int internalWire29 ;
  int internalWire30 ;
  int internalWire31 ;

  const int omegaRealStage1 = 10 ;
  const int omegaImagStage1 = 1 ;

  const int omegaRealStage2 = 20 ;
  const int omegaImagStage2 = 2 ;

  const int omegaRealStage3 = 30 ;
  const int omegaImagStage3 = 3 ;

  int output0 ;
  int output1 ;
  int output2 ;
  int output3 ;
  int output4 ;
  int output5 ;
  int output6 ;
  int output7 ;
  int output8 ;
  int output9 ;
  int output10 ;
  int output11 ;
  int output12 ;
  int output13 ;
  int output14 ;
  int output15 ;

  for (i = 0 ; i < 100 ; i+=16)
  {

    // The order in which the mapping is expected:
    // FFTOneStage(
    //              x1Imag_out,
    //              x1Real_out,
    //              x0Imag_out,
    //              imag0_in,
    //              x0Real_out,
    //              imag1_in,
    //              imagOmega_in,
    //              real1_in,
    //              realOmega_in,
    //              real0_in,
    //              x3Imag_out,
    //              x3Real_out,
    //              x2Imag_out,
    //              imag2_in,
    //              x2Real_out,
    //              imag3_in,
    //              real3_in,
    //              real2_in,
    //              x5Imag_out,
    //              x4Imag_out,
    //              imag4_in,
    //              x4Real_out,
    //              imag5_in,
    //              real5_in,
    //              real4_in,
    //              x7Imag_out,
    //              x7Real_out,
    //              x6Imag_out,
    //              imag6_in,
    //              x6Real_out,
    //              imag7_in,
    //              real7_in,
    //              real6_in);


    // Stage 1
    //
    // A[i] -> A[i+15] correspond to the real, imag pairs of the first eight
    //  values.
    //
    // The outputs are internalWire0-15 and represent the real, imag pairs
    //  of x0->x7
    // x0Real -> internalWire0
    // x0Imag -> internalWire1
    // x1Real -> internalWire2
    // x1Imag -> internalWire3
    // x2Real -> internalWire4
    // x2Imag -> internalWire5
    // x3Real -> internalWire6
    // x3Imag -> internalWire7
    // x4Real -> internalWire8
    // x4Imag -> internalWire9
    // x5Real -> internalWire10
    // x5Imag -> internalWire11
    // x6Real -> internalWire12
    // x6Imag -> internalWire13
    // x7Real -> internalWire14
    // x7Imag -> internalWire15

    FFTOneStage(internalWire3,
		internalWire2,
		internalWire1,
		A[i+1],
		internalWire0,
		A[i+9],
		omegaImagStage1,
		A[i+8],
		omegaRealStage1,
		A[i],
		internalWire7,
		internalWire6,
		internalWire5,
		A[i+5],
		internalWire4,
		A[i+13],
	        A[i+12],
		A[i+4],
		internalWire11,
		internalWire10,
		internalWire9,
		A[i+3],
		internalWire8,
		A[i+11],
		A[i+10],
		A[i+2],
		internalWire15,
		internalWire14,
		internalWire13,
		A[i+7],
		internalWire12,
		A[i+15],
		A[i+14],
		A[i+6]);


    // Stage 2
    FFTOneStage(
		internalWire19, // x1Imag_out,
		internalWire18, // x1Real_out,
		internalWire17, // x0Imag_out
		internalWire1,  // imag0_in,
		internalWire16, // x0Real_out,
		internalWire5,  // imag1_in,
		omegaImagStage2, // imagOmega_in,
		internalWire4, // real1_in,
		omegaRealStage2, // realOmega_in,
		internalWire0, // real0_in,
		internalWire23, // x3Imag_out,
		internalWire22, // x3Real_out,
		internalWire21, // x2Imag_out,
		internalWire9, // imag2_in,
		internalWire20, // x2Real_out,
		internalWire13, // imag3_in,
		internalWire12, // real3_in,
		internalWire8, // real2_in,
		internalWire27, // x5Imag_out,
		internalWire26, // x5Real_out
		internalWire25, // x4Imag_out,
		internalWire3, // imag4_in,
		internalWire24, // x4Real_out,
		internalWire7, // imag5_in,
		internalWire6, // real5_in,
		internalWire2, // real4_in,
		internalWire31, // x7Imag_out,
		internalWire30, // x7Real_out,
		internalWire29, // x6Imag_out,
		internalWire11, // imag6_in,
		internalWire28, // x6Real_out,
		internalWire15, // imag7_in,
		internalWire14, // real7_in,
		internalWire10  // real6_in
	       ) ;

    // Stage 3

    FFTOneStage(
		output3, // x1Imag_out,
		output2, // x1Real_out,
		output1, // x0Imag_out,
		internalWire17, // imag0_in,
		output0, // x0Real_out,
		internalWire25, // imag1_in,
		omegaImagStage3, // imagOmega_in,
		internalWire24, // real1_in,
		omegaRealStage3, // realOmega_in,
		internalWire16, // real0_in,
		output7, // x3Imag_out,
		output6, // x3Real_out,
		output5, // x2Imag_out,
		internalWire21, // imag2_in,
		output4, // x2Real_out,
		internalWire29, // imag3_in,
		internalWire28, // real3_in,
		internalWire20, // real2_in,
		output11, // x5Imag_out,
		output10, // x5Real_out
		output9, // x4Imag_out,
		internalWire19, // imag4_in,
		output8, // x4Real_out,
		internalWire27, // imag5_in,
		internalWire26, // real5_in,
		internalWire18, // real4_in,
		output15, // x7Imag_out,
		output14, // x7Real_out,
		output13, // x6Imag_out,
		internalWire23, // imag6_in,
		output12, // x6Real_out,
		internalWire31, // imag7_in,
		internalWire30, // real7_in,
		internalWire22  // real6_in
	       ) ;


    B[i+0] = output0 ;
    B[i+1] = output1 ;
    B[i+2] = output2 ;
    B[i+3] = output3 ;
    B[i+4] = output4 ;
    B[i+5] = output5 ;
    B[i+6] = output6 ;
    B[i+7] = output7 ;
    B[i+8] = output8 ;
    B[i+9] = output9 ;
    B[i+10] = output10 ;
    B[i+11] = output11 ;
    B[i+12] = output12 ;
    B[i+13] = output13 ;
    B[i+14] = output14 ;
    B[i+15] = output15 ;

  }
  
}
