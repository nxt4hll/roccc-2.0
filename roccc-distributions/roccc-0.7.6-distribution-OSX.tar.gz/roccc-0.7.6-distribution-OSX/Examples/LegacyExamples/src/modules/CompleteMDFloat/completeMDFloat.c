/*

  This file represents a hardware module that performs the force
   calculations between two atoms in a single timestep in a molecular
   dynamics simulation.  This is done in single precision floating point.

  You must compile the MD-Float example before compiling this file.

*/

#include "roccc-library.h"

typedef struct
{
  float atomOneCurrentX_in ;
  float atomOneCurrentY_in ;
  float atomOneCurrentZ_in ;
  float atomOneCurrentCharge_in ;

  float atomTwoCurrentX_in ;
  float atomTwoCurrentY_in ;
  float atomTwoCurrentZ_in ;
  float atomTwoCurrentCharge_in ;

  float currentConstant12_in ;
  float currentConstant6_in ;
  float tableLookup_in ;

  float VanDerWaalEnergy_out ;
  float CoulombicForceX_out ;
  float CoulombicForceY_out ;
  float CoulombicForceZ_out ;

} CompleteMDFloat_t ;

CompleteMDFloat_t CompleteMDFloat(CompleteMDFloat_t md)
{
  float twelfthTerm ;
  float sixthTerm ;
  float radiusToTheTwelfth ;
  float radiusToTheSixth ;
  float radiusSquared ;
  float distanceXSquared ;
  float differenceX ;
  float distanceYSquared ;
  float differenceY ;
  float distanceZSquared ;
  float differenceZ ;

  // Call the Coulombic force module
  MDFloat(md.atomOneCurrentX_in,
	  md.atomTwoCurrentX_in,
	  md.atomOneCurrentY_in,
	  md.atomTwoCurrentY_in,
	  md.atomOneCurrentZ_in,
	  md.atomTwoCurrentZ_in,
	  md.tableLookup_in,
	  md.atomOneCurrentCharge_in,
	  md.atomTwoCurrentCharge_in,
	  md.CoulombicForceX_out,
	  md.CoulombicForceY_out,
	  md.CoulombicForceZ_out) ;

  // Perform the calculations for the VanDerWaal Energy

  differenceX = md.atomOneCurrentX_in - md.atomTwoCurrentX_in ;
  differenceY = md.atomOneCurrentY_in - md.atomTwoCurrentY_in ;
  differenceZ = md.atomOneCurrentZ_in - md.atomTwoCurrentZ_in ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;
  
  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;
  radiusToTheSixth = radiusSquared * radiusSquared * radiusSquared ;
  radiusToTheTwelfth = radiusToTheSixth * radiusToTheSixth ;

  twelfthTerm = md.currentConstant12_in * radiusToTheTwelfth ;
  sixthTerm = md.currentConstant6_in * radiusToTheSixth ;

  md.VanDerWaalEnergy_out = twelfthTerm - sixthTerm ;

  return md ;

}
