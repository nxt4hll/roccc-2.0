/*

  This file represents a hardware module that performs a subset of the 
    calculations necessary for each timestep in a molecular dynamics
    simulation.  This takes in the data for two atoms in single
    precision floating point format and produces the Columbic forces
    in the X, Y, and Z direction.

*/

typedef struct
{
  float atomOneCurrentX_in ;
  float atomOneCurrentY_in ;
  float atomOneCurrentZ_in ;
  float atomOneCurrentCharge_in ;

  float atomTwoCurrentX_in ;
  float atomTwoCurrentY_in ;
  float atomTwoCurrentZ_in ;
  float atomTwoCurrentCharge_in ;

  float tableLookup_in ;
  
  float CoulombicForceX_out ;
  float CoulombicForceY_out ;
  float CoulombicForceZ_out ;

} MDFloat_t ;

MDFloat_t MDFloat(MDFloat_t m)
{
  float twelfthTerm ;
  float sixthTerm ;
  float radiusToTheTwelfth ;
  float radiusToTheSixth ;
  float radiusSquared ;
  float distanceXSquared ;
  float distanceYSquared ;
  float distanceZSquared ;
  float differenceX ;
  float differenceY ;
  float differenceZ ;
  float vcoul ;
  float rinvsq ;
  float rinv ;

  differenceX = m.atomOneCurrentX_in - m.atomTwoCurrentX_in ;
  differenceY = m.atomOneCurrentY_in - m.atomTwoCurrentY_in ;
  differenceZ = m.atomOneCurrentZ_in - m.atomTwoCurrentZ_in ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;

  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;
  
  rinv = (m.tableLookup_in * (((radiusSquared * m.tableLookup_in) * m.tableLookup_in))) ;

  vcoul = m.atomOneCurrentCharge_in * m.atomTwoCurrentCharge_in * rinv ;

  rinvsq = rinv * rinv ;

  m.CoulombicForceX_out = vcoul * rinvsq * differenceX ;
  m.CoulombicForceY_out = vcoul * rinvsq * differenceY ;
  m.CoulombicForceZ_out = vcoul * rinvsq * differenceZ ;

  return m ;
}
