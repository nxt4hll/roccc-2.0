
void blank()
{
}
