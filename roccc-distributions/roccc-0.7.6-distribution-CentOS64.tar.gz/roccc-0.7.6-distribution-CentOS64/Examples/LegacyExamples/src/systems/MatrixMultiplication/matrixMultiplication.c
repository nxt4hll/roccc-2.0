/*
  In order for this example to compile, you must select loop unrolling on the
    innermost loop.  You may also choose to unroll the other loops.
*/
void MatrixSystem()
{
  int A[10][10] ;
  int B[10][10] ;
  int C0[10][10] ;
  
  int i ;
  int j ;
  int k ;
  int currentSum ;

  for (i = 0 ; i < 10 ; ++i)
  {
  L2: for (j = 0 ; j < 10 ; ++j)
    {
      currentSum = 0 ; 
    L1: for (k = 0 ; k < 10 ; ++k)
      {
	currentSum += A[i][k] * B[k][j] ;
      }
      C0[i][j] = currentSum ;
    }
  }
  
}
