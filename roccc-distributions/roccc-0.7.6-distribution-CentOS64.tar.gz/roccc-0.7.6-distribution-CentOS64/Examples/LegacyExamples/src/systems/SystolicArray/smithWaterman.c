
void SmithWaterman()
{
  int i ;
  int j ;
  
  int A[11][11] ;
  int T[11] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 } ;
  const int S[11] = { 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 } ;
  
  // These constants are adjustable
  const int matchCost = 10 ;
  const int mismatchCost = 100 ;
  const int insertCost = 20 ;
  const int deleteCost = 200 ;

  int tmp ;
  int tmp2 ;
  int tmp3 ;
  int tmp4 ;

 L1: for (i = 0 ; i < 11 ; ++i)
  {
    for (j = 0 ; j < 11 ; ++j)
    {
      if (S[i] == T[j])
      {
	tmp = A[i-1][j-1] + matchCost ;
      }
      else
      {
	tmp = A[i-1][j-1] + mismatchCost ;
      }

      if (A[i-1][j] + insertCost > A[i][j-1] + deleteCost)
      {
	tmp2 = A[i-1][j] + insertCost ;
      }
      else
      {
	tmp2 = A[i][j-1] + deleteCost ;
      }

      if (tmp > tmp2)
      {
	tmp3 = tmp ;
      }
      else
      {
	tmp3 = tmp2 ;
      }

      if (tmp3 < 0)
      {
	A[i][j] = 0 ;
      }
      else
      {
	A[i][j] = tmp3 ;
      }
    }
  }
}
