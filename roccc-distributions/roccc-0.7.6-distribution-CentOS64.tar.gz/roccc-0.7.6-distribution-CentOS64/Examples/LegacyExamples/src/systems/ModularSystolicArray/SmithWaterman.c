
#include "roccc-library.h"

typedef int ROCCC_int2 ;
typedef int ROCCC_int8 ;

void ModularSmithWaterman()
{
  ROCCC_int8 A[36][10] ;

  const int S[36] = 
    {
      0, 1, 2, 3, 0, 1, 2, 3, 0, 1,
      0, 1, 2, 3, 0, 1, 2, 3, 0, 1,
      0, 1, 2, 3, 0, 1, 2, 3, 0, 1,
      0, 1, 2, 3, 0, 1
    } ;

  ROCCC_int8 T[10] ;
  ROCCC_int8 tmpResult ;

  int i ;
  int j ;

 L1: for (i = 0 ; i < 36 ; ++i)
  {
    for (j = 0 ; j < 10 ; ++j)
    {
      SingleCell(S[i], T[j], A[i-1][j-1], A[i-1][j], A[i][j-1], tmpResult) ;
      A[i][j] = tmpResult ;
    }
  }
}
