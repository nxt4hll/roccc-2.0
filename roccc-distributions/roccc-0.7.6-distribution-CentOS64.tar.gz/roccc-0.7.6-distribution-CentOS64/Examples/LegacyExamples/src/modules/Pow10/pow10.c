/*
  This example shows that modules can have loops that will be fully unrolled.
*/

typedef struct
{
  int x_in ;
  int y_out ;
} Pow10_t ;

Pow10_t Pow10(Pow10_t t)
{
  int total ;
  int i ;

  total = 1 ;
  
  for (i = 0 ; i < 10 ; ++i)
  {
    total *= t.x_in ;
  }

  t.y_out = total ;

  return t ;
}
