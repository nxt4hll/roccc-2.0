/*

  This file represents a hardware module that performs the calculations between
    two atoms for one timestep in a molecular dynamics simulation.  The
    Coulombic forces are calculated through the use of the previously
    compiled MD module and the Van Der Waal forces are computed 
    in parallel.

  Note, you must have compiled the MD module before compiling this file.

*/

#include "roccc-library.h"

typedef struct
{
  int atomOneCurrentX_in ;
  int atomOneCurrentY_in ;
  int atomOneCurrentZ_in ;
  int atomOneCurrentCharge_in ;

  int atomTwoCurrentX_in ;
  int atomTwoCurrentY_in ;
  int atomTwoCurrentZ_in ;
  int atomTwoCurrentCharge_in ;

  int currentConstant12_in ;
  int currentConstant6_in ;
  int tableLookup_in ;

  int VanDerWaalEnergy_out ;
  int CoulombicForceX_out ;
  int CoulombicForceY_out ;
  int CoulombicForceZ_out ;

} CompleteMD_t ;

CompleteMD_t CompleteMD(CompleteMD_t md)
{
  int twelfthTerm ;
  int sixthTerm ;
  int radiusToTheTwelfth ;
  int radiusToTheSixth ;
  int radiusSquared ;
  int distanceXSquared ;
  int differenceX ;
  int distanceYSquared ;
  int differenceY ;
  int distanceZSquared ;
  int differenceZ ;

  // Call the Coulombic force module
  MD(md.atomOneCurrentX_in,
     md.atomTwoCurrentX_in,
     md.atomOneCurrentY_in,
     md.atomTwoCurrentY_in,
     md.atomOneCurrentZ_in,
     md.atomTwoCurrentZ_in,
     md.tableLookup_in,
     md.atomOneCurrentCharge_in,
     md.atomTwoCurrentCharge_in,
     md.CoulombicForceX_out,
     md.CoulombicForceY_out,
     md.CoulombicForceZ_out) ;

  // Perform the calculations for the VanDerWaal Energy

  differenceX = md.atomOneCurrentX_in - md.atomTwoCurrentX_in ;
  differenceY = md.atomOneCurrentY_in - md.atomTwoCurrentY_in ;
  differenceZ = md.atomOneCurrentZ_in - md.atomTwoCurrentZ_in ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;
  
  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;
  radiusToTheSixth = radiusSquared * radiusSquared * radiusSquared ;
  radiusToTheTwelfth = radiusToTheSixth * radiusToTheSixth ;

  twelfthTerm = md.currentConstant12_in * radiusToTheTwelfth ;
  sixthTerm = md.currentConstant6_in * radiusToTheSixth ;

  md.VanDerWaalEnergy_out = twelfthTerm - sixthTerm ;

  return md ;

}
