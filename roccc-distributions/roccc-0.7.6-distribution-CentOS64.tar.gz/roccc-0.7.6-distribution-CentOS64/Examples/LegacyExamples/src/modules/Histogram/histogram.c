/*

  This component represents one stage in a hardware histogram circuit.
    Each stage is responsible for keeping track of one value as a large
    data set is streamed through, with the output of one stage leading directly
    into another.

*/

typedef struct
{
  // Inputs
  int Count_in ;
  int Value_in ;
  int Input_in ;
  int Valid_in ;

  // Outputs
  int Count_out ;
  int Value_out ;
  int Stream_out ;
  int Valid_out ;

} Histogram_t ;

// The way this histogram block works is every block is initialized with a 
//  value of 0 and a count of 0.  If the count is 0, grab the first value 
//  you see on the input stream and store it.  On all subsequent input values, 
//  check to see if the value is the same as the stored value.

Histogram_t Histogram(Histogram_t h)
{
  int Tmp1 ;
  Tmp1 = (h.Count_in == 0) & (h.Valid_in == 1) ;
  if (Tmp1)
  {
    h.Value_out = h.Input_in ;
  }
  else
  {
    h.Value_out = h.Value_in ;
  }
  if (Tmp1 | ((h.Valid_in == 1) & (h.Value_in == h.Input_in)))
  {
    h.Count_out = h.Count_in + 1 ;
  }
  else
  {
    h.Count_out = h.Count_in ;
  }
  if (Tmp1 | ((h.Valid_in == 1) & (h.Value_in == h.Input_in)))
  {
    h.Valid_out = 0 ;
  }
  else
  {
    h.Valid_out = h.Valid_in ;
  }
  if (Tmp1 | ((h.Valid_in == 1) & (h.Value_in == h.Input_in)))
  {
    h.Stream_out = 0 ;
  }
  else
  {
    h.Stream_out = h.Input_in ;
  }
  return h ;
}

