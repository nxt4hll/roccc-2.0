
#include "roccc-library.h"

typedef struct
{

  int real0_in ;
  int imag0_in ;
  int real1_in ;
  int imag1_in ;
  int real2_in ;
  int imag2_in ;
  int real3_in ;
  int imag3_in ;
  int real4_in ;
  int imag4_in ;
  int real5_in ;
  int imag5_in ;
  int real6_in ;
  int imag6_in ;
  int real7_in ;
  int imag7_in ;

  int realOmega_in ;
  int imagOmega_in ;

  int x0Real_out ;
  int x0Imag_out ;
  int x1Real_out ;
  int x1Imag_out ;
  int x2Real_out ;
  int x2Imag_out ;
  int x3Real_out ;
  int x3Imag_out ;
  int x4Real_out ;
  int x4Imag_out ;
  int x5Real_out ;
  int x5Imag_out ;
  int x6Real_out ;
  int x6Imag_out ;
  int x7Real_out ;
  int x7Imag_out ;

} FFTOneStage_t ;

FFTOneStage_t FFTOneStage(FFTOneStage_t t)
{

  // The order in which each FFT expects the parameters is:
  //  (Real0, RealOmega, Real1, ImagOmega, Imag1, x0Real, Imag0, 
  //   x0Imag, x1Real, x1Imag) 

  // In the definition of FFTOneStage each block is numbered from 
  //  the top down in increasing order.  The criss-crossing is done at
  //  the higher level when we instantiate these blocks.

  // There are four butterfly operations per stage.
  FFT(t.real0_in,
      t.realOmega_in,
      t.real1_in,
      t.imagOmega_in,
      t.imag1_in,
      t.x0Real_out,
      t.imag0_in,
      t.x0Imag_out,
      t.x1Real_out,
      t.x1Imag_out) ;

  FFT(t.real2_in,
      t.realOmega_in,
      t.real3_in,
      t.imagOmega_in,
      t.imag3_in,
      t.x2Real_out,
      t.imag2_in,
      t.x2Imag_out,
      t.x3Real_out,
      t.x3Imag_out) ;

  FFT(t.real4_in,
      t.realOmega_in,
      t.real5_in,
      t.imagOmega_in,
      t.imag5_in,
      t.x4Real_out,
      t.imag4_in,
      t.x4Imag_out,
      t.x5Real_out,
      t.x5Imag_out) ;

  FFT(t.real6_in,
      t.realOmega_in,
      t.real7_in,
      t.imagOmega_in,
      t.imag7_in,
      t.x6Real_out,
      t.imag6_in,
      t.x6Imag_out,
      t.x7Real_out,
      t.x7Imag_out) ;

  return t ;
}
