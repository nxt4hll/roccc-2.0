/*

  This example is a simple hardware module that determines the maximum of
    three inputs.  This example shows the supported use of if statements 
    in ROCCC.

*/

typedef struct 
{
  // Inputs
  int A0_in ;
  int A1_in ;
  int A2_in ;

  // Outputs
  int max_out ;

} MAX_t ;

MAX_t MAX(MAX_t m)
{
  int tmp1 ;

  if (m.A0_in > m.A1_in)
  {
    tmp1 = m.A0_in ;
  }
  else
  {
    tmp1 = m.A1_in ;
  }

  if (tmp1 > m.A2_in)
  {
    m.max_out = tmp1 ;
  }
  else
  {
    m.max_out = m.A2_in ;
  }
  
  return m ;
}

