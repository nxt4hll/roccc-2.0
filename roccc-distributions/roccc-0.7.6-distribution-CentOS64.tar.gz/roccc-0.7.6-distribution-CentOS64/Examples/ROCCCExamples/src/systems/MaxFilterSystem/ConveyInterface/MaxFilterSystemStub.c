#include <convey/usr/cny_comp.h>
#include <assert.h>
#include <stdio.h>
typedef unsigned long long uint64 ;
extern long rocccCall() ;
void Stub(int* window, int* max, int height, int width)
{
	cny_image_t sig ;
	cny_image_t sig2 ;
	uint64 finalValue ;
	uint64* inputParameters ;
	uint64* outputParameters ;
	assert(cny$get_signature_fptr != NULL) ;
	assert(cny_cp_interleave() != CNY_MI_3131) ;
	assert(cny$cp_malloc_fptr != NULL) ;
	(*cny$get_signature_fptr)("PLACE_SIGNATURE_HERE", &sig, &sig2) ;
	inputParameters = (uint64*)(*cny$cp_malloc_fptr)(4*8) ;
	inputParameters[0] = (uint64)window ;
	inputParameters[1] = (uint64)max ;
	inputParameters[2] = (uint64)height ;
	inputParameters[3] = (uint64)width ;
	finalValue = l_copcall_fmt(sig, rocccCall, "A", inputParameters) ;
}
