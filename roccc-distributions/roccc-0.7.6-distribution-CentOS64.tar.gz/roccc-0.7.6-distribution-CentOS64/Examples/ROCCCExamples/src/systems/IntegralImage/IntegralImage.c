// This code calculates an integral image on a square image.  The integral
//  image has at every point the sum of the original image pixels that are
//  north and west of the point.

// This can be any size, but just as an example we'll use a 10x10 picture 

void Integral(int** image, int** output)
{
  int i, j ;
  // Declare a local lookup table
  int integral[10][10] ; // Initialized to 0's by default
  int value ;

  for (i = 0 ; i < 10 ; ++i)
  {
    for (j = 0 ; j < 10 ; ++j)
    {
      value = image[i][j] +
              integral[i-1][j] + integral[i][j-1] - integral[i-1][j-1] ;
      integral[i][j] = value ;
      output[i][j] = value ;
    }
  }
}

