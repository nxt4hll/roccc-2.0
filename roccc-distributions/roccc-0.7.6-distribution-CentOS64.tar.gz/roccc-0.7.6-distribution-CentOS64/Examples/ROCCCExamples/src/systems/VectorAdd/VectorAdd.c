// This example performs the addition of two vectors and stores it into
//   a third vector.  This can be unrolled and parallelized through the
//   user-controlled optimizations.

void VectorAdd(int* A, int* B, int N, int* Out)
{
  int i ;
  L1: for (i = 0 ; i < N ; ++i)
  {
    Out[i] = A[i] + B[i] ;
  }
}
