// This code sums up all elements of a stream and outputs a single scalar
//  that holds the sum.

void VectorReduction(int* A, int N, int& sum)
{
  int i ;
  int cumulative = 0 ;
  for (i = 0 ; i < N ; ++i)
  {
    cumulative += A[i] ;
    sum = cumulative ;
  }
}
