#include <convey/usr/cny_comp.h>
#include <assert.h>
#include <stdio.h>
typedef unsigned long long uint64 ;
extern long rocccCall() ;
void Stub(int* A, int* B, int* C, int length, int currentSum_init)
{
	cny_image_t sig ;
	cny_image_t sig2 ;
	uint64 finalValue ;
	uint64* inputParameters ;
	uint64* outputParameters ;
	assert(cny$get_signature_fptr != NULL) ;
	assert(cny_cp_interleave() != CNY_MI_3131) ;
	assert(cny$cp_malloc_fptr != NULL) ;
	(*cny$get_signature_fptr)("PLACE_SIGNATURE_HERE", &sig, &sig2) ;
	inputParameters = (uint64*)(*cny$cp_malloc_fptr)(5*8) ;
	inputParameters[0] = (uint64)A ;
	inputParameters[1] = (uint64)B ;
	inputParameters[2] = (uint64)C ;
	inputParameters[3] = (uint64)length ;
	inputParameters[4] = (uint64)currentSum_init ;
	finalValue = l_copcall_fmt(sig, rocccCall, "A", inputParameters) ;
}
