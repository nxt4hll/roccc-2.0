// This module takes eight values and returns eight sorted values.  It is
//  created by instantiating six parallel levels of 2-input Bitonic sorts

#include "roccc-library.h"

void BitonicSort8(int a1, int a2, int a3, int a4,
                  int a5, int a6, int a7, int a8,
                  int& o1, int& o2, int& o3, int& o4,
                  int& o5, int& o6, int& o7, int& o8)
{
  // The first level
  int b1, b2, b3, b4, b5, b6, b7, b8 ;
  BitonicSort2(a1, a2, b1, b2) ;
  BitonicSort2(a3, a4, b3, b4) ;
  BitonicSort2(a5, a6, b5, b6) ;
  BitonicSort2(a7, a8, b7, b8) ;

  // The second level
  int c1, c2, c3, c4, c5, c6, c7, c8 ;
  BitonicSort2(b1, b4, c1, c4) ;
  BitonicSort2(b2, b3, c2, c3) ;
  BitonicSort2(b5, b8, c5, c8) ;
  BitonicSort2(b6, b7, c6, c7) ;

  // The third level 
  int d1, d2, d3, d4, d5, d6, d7, d8 ;
  BitonicSort2(c1, c2, d1, d2) ;
  BitonicSort2(c3, c4, d3, d4) ;
  BitonicSort2(c5, c6, d5, d6) ;
  BitonicSort2(c7, c8, d7, d8) ;

  // The fourth level 
  int e1, e2, e3, e4, e5, e6, e7, e8 ;
  BitonicSort2(d1, d8, e1, e8) ;
  BitonicSort2(d2, d7, e2, e7) ;
  BitonicSort2(d3, d6, e3, e6) ;
  BitonicSort2(d4, d5, e4, e5) ;

  // The fifth level 
  int f1, f2, f3, f4, f5, f6, f7, f8 ;
  BitonicSort2(e1, e3, f1, f3) ;
  BitonicSort2(e2, e4, f2, f4) ;
  BitonicSort2(e5, e7, f5, f7) ;
  BitonicSort2(e6, e8, f6, f8) ;

  // The sixth level
  int g1, g2, g3, g4, g5, g6, g7, g8 ;
  BitonicSort2(f1, f2, g1, g2) ;
  BitonicSort2(f3, f4, g3, g4) ;
  BitonicSort2(f5, f6, g5, g6) ;
  BitonicSort2(f7, f8, g7, g8) ;

  o1 = g1 ;
  o2 = g2 ;
  o3 = g3 ;
  o4 = g4 ;
  o5 = g5 ;
  o6 = g6 ;
  o7 = g7 ;
  o8 = g8 ;
}
