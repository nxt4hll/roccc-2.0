#include <convey/usr/cny_comp.h>
#include <assert.h>
#include <stdio.h>
typedef unsigned long long uint64 ;
extern long rocccCall() ;
void Stub(int a1, int a2, int a3, int a4, int a5, int a6, int a7, int a8, int* o1_out, int* o2_out, int* o3_out, int* o4_out, int* o5_out, int* o6_out, int* o7_out, int* o8_out)
{
	cny_image_t sig ;
	cny_image_t sig2 ;
	uint64 finalValue ;
	uint64* inputParameters ;
	uint64* outputParameters ;
	assert(cny$get_signature_fptr != NULL) ;
	assert(cny_cp_interleave() != CNY_MI_3131) ;
	assert(cny$cp_malloc_fptr != NULL) ;
	(*cny$get_signature_fptr)("PLACE_SIGNATURE_HERE", &sig, &sig2) ;
	inputParameters = (uint64*)(*cny$cp_malloc_fptr)(8*8) ;
	outputParameters = (uint64*)(*cny$cp_malloc_fptr)(8*8) ;
	inputParameters[0] = (uint64)a1 ;
	inputParameters[1] = (uint64)a2 ;
	inputParameters[2] = (uint64)a3 ;
	inputParameters[3] = (uint64)a4 ;
	inputParameters[4] = (uint64)a5 ;
	inputParameters[5] = (uint64)a6 ;
	inputParameters[6] = (uint64)a7 ;
	inputParameters[7] = (uint64)a8 ;
	finalValue = l_copcall_fmt(sig, rocccCall, "AA", inputParameters, outputParameters) ;
	*o1_out = outputParameters[0] ;
	*o2_out = outputParameters[1] ;
	*o3_out = outputParameters[2] ;
	*o4_out = outputParameters[3] ;
	*o5_out = outputParameters[4] ;
	*o6_out = outputParameters[5] ;
	*o7_out = outputParameters[6] ;
	*o8_out = outputParameters[7] ;
}
