// This module takes two inputs and returns two sorted outputs

void BitonicSort2(int a, int b, int& o1, int& o2)
{
  if (a < b)
  {
    o1 = a ;
    o2 = b ;
  }
  else
  {
    o1 = b ;
    o2 = a ;
  }
}
