/*
 This file contains all of the exported functions and structs
  that can be called as hardware modules.  This file is
  automatically generated and updated after every successful
  compilation of a module
*/

#ifndef __ROCCC_LIBRARY_DOT_H__
#define __ROCCC_LIBRARY_DOT_H__

#endif
