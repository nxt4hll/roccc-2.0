// This module performs the true FFT on eight complex numbers. 
//  It consists of three parallel stages of FFT operations each with 
//  their own unique omega value and butterflies the connections between
//  them.

#include "roccc-library.h"

typedef int ROCCC_int64 ;

void FFT8(ROCCC_int64 real0, ROCCC_int64 imag0,
          ROCCC_int64 real1, ROCCC_int64 imag1,
          ROCCC_int64 real2, ROCCC_int64 imag2,
          ROCCC_int64 real3, ROCCC_int64 imag3,
          ROCCC_int64 real4, ROCCC_int64 imag4,
          ROCCC_int64 real5, ROCCC_int64 imag5,
          ROCCC_int64 real6, ROCCC_int64 imag6,
          ROCCC_int64 real7, ROCCC_int64 imag7,
          ROCCC_int64 realOmega1, ROCCC_int64 imagOmega1,
          ROCCC_int64 realOmega2, ROCCC_int64 imagOmega2,
          ROCCC_int64 realOmega3, ROCCC_int64 imagOmega3,
          ROCCC_int64& x0Real, ROCCC_int64& x0Imag,
          ROCCC_int64& x1Real, ROCCC_int64& x1Imag,
          ROCCC_int64& x2Real, ROCCC_int64& x2Imag,
          ROCCC_int64& x3Real, ROCCC_int64& x3Imag,
          ROCCC_int64& x4Real, ROCCC_int64& x4Imag,
          ROCCC_int64& x5Real, ROCCC_int64& x5Imag,
          ROCCC_int64& x6Real, ROCCC_int64& x6Imag,
          ROCCC_int64& x7Real, ROCCC_int64& x7Imag)
{

  // The wires to connect the first stage with the second stage
  ROCCC_int64 internalWire0 ;
  ROCCC_int64 internalWire1 ;
  ROCCC_int64 internalWire2 ;
  ROCCC_int64 internalWire3 ;
  ROCCC_int64 internalWire4 ;
  ROCCC_int64 internalWire5 ;
  ROCCC_int64 internalWire6 ;
  ROCCC_int64 internalWire7 ;
  ROCCC_int64 internalWire8 ;
  ROCCC_int64 internalWire9 ;
  ROCCC_int64 internalWire10 ;
  ROCCC_int64 internalWire11 ;
  ROCCC_int64 internalWire12 ;
  ROCCC_int64 internalWire13 ;
  ROCCC_int64 internalWire14 ;
  ROCCC_int64 internalWire15 ;

  // The wires to connect the second stage with the third stage

  ROCCC_int64 internalWire16 ;
  ROCCC_int64 internalWire17 ;
  ROCCC_int64 internalWire18 ;
  ROCCC_int64 internalWire19 ;
  ROCCC_int64 internalWire20 ;
  ROCCC_int64 internalWire21 ;
  ROCCC_int64 internalWire22 ;
  ROCCC_int64 internalWire23 ;
  ROCCC_int64 internalWire24 ;
  ROCCC_int64 internalWire25 ;
  ROCCC_int64 internalWire26 ;
  ROCCC_int64 internalWire27 ;
  ROCCC_int64 internalWire28 ;
  ROCCC_int64 internalWire29 ;
  ROCCC_int64 internalWire30 ;
  ROCCC_int64 internalWire31 ;

  // The first stage
  FFT4(real0, imag0, real1, imag1, real2, imag2, real3, imag3,
       real4, imag4, real5, imag5, real6, imag6, real7, imag7,
       realOmega1, imagOmega1,
       internalWire0, internalWire1, internalWire2, internalWire3,
       internalWire4, internalWire5, internalWire6, internalWire7,
       internalWire8, internalWire9, internalWire10, internalWire11,
       internalWire12, internalWire13, internalWire14, internalWire15) ;

  // Butterfly the inputs to the second stage 
  FFT4(internalWire0, internalWire1, internalWire4, internalWire5,
       internalWire8, internalWire9, internalWire12, internalWire13,
       internalWire2, internalWire3, internalWire6, internalWire7,
       internalWire10, internalWire11, internalWire14, internalWire15,
       realOmega2, imagOmega2,
       internalWire16, internalWire17, internalWire18, internalWire19,
       internalWire20, internalWire21, internalWire22, internalWire23,
       internalWire24, internalWire25, internalWire26, internalWire27,
       internalWire28, internalWire29, internalWire30, internalWire31) ;

  // Butterfly the inputs to the final stage
  FFT4(internalWire16, internalWire17, internalWire24, internalWire25,
       internalWire20, internalWire21, internalWire28, internalWire29,
       internalWire18, internalWire19, internalWire26, internalWire27,
       internalWire22, internalWire23, internalWire30, internalWire31,
       realOmega3, imagOmega3,
       x0Real, x0Imag, x1Real, x1Imag, 
       x2Real, x2Imag, x3Real, x3Imag,
       x4Real, x4Imag, x5Real, x5Imag, 
       x6Real, x6Imag, x7Real, x7Imag) ;
}

