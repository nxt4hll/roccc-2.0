// This program will perform a saturating addition for two eight bit values.
//  This is accomplished by storing the result of the addition into a
//  nine bit value.  ROCCC will correctly catch any addition overflow from the
//  eight bit addition into the topmost bit of the nine bit integer.

typedef unsigned int ROCCC_int8 ;
typedef unsigned int ROCCC_int9 ;

void SatAdd(ROCCC_int8 x, ROCCC_int8 y, ROCCC_int8& z)
{
  ROCCC_int9 tmp ;
  tmp = x + y ;
  if (tmp > 255)
  {
    z = 255 ;
  }
  else
  {
    z = tmp ;
  }
}
