// This file performs four FFT operations in parallel.  It is a necessary 
//  component used to build up the true FFT on eight complex numbers. 
//  This takes eight complex numbers and a complex omega and outputs
//  the intermediate complex values for an eight input FFT.

#include "roccc-library.h"

typedef int ROCCC_int64 ;

void FFT4(ROCCC_int64 real0, ROCCC_int64 imag0,
          ROCCC_int64 real1, ROCCC_int64 imag1,
          ROCCC_int64 real2, ROCCC_int64 imag2,
          ROCCC_int64 real3, ROCCC_int64 imag3,
          ROCCC_int64 real4, ROCCC_int64 imag4,
          ROCCC_int64 real5, ROCCC_int64 imag5,
          ROCCC_int64 real6, ROCCC_int64 imag6,
          ROCCC_int64 real7, ROCCC_int64 imag7,
          ROCCC_int64 realOmega, ROCCC_int64 imagOmega,
          ROCCC_int64& x0Real, ROCCC_int64& x0Imag,
          ROCCC_int64& x1Real, ROCCC_int64& x1Imag,
          ROCCC_int64& x2Real, ROCCC_int64& x2Imag,
          ROCCC_int64& x3Real, ROCCC_int64& x3Imag,
          ROCCC_int64& x4Real, ROCCC_int64& x4Imag,
          ROCCC_int64& x5Real, ROCCC_int64& x5Imag,
          ROCCC_int64& x6Real, ROCCC_int64& x6Imag,
          ROCCC_int64& x7Real, ROCCC_int64& x7Imag)
{
  FFT2(real0, imag0, real1, imag1, realOmega, imagOmega,
       x0Real, x0Imag, x1Real, x1Imag) ;
  FFT2(real2, imag2, real3, imag3, realOmega, imagOmega,
       x2Real, x2Imag, x3Real, x3Imag) ;
  FFT2(real4, imag4, real5, imag5, realOmega, imagOmega,
       x4Real, x4Imag, x5Real, x5Imag) ;
  FFT2(real6, imag6, real7, imag7, realOmega, imagOmega,
       x6Real, x6Imag, x7Real, x7Imag) ;
}
