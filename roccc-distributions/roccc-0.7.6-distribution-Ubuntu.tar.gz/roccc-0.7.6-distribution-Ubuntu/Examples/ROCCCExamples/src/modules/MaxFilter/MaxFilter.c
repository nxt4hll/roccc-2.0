// This module outputs the maximum value from among three integer inputs

void MaxFilter(int A0, int A1, int A2, int& max)
{
  int tmp ;
  if (A0 > A1)
  {
    tmp = A0 ;
  }
  else
  {
    tmp = A1 ;
  }

  if (tmp > A2)
  {
    max = tmp ;
  }
  else
  {
    max = A2 ;
  }
}
