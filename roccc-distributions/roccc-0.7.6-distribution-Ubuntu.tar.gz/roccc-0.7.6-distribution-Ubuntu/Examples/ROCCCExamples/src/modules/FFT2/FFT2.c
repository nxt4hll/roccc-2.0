// This module takes two complex numbers and a complex omega and 
//  outputs the FFT as two complex numbers.

typedef int ROCCC_int64 ;

void FFT2(ROCCC_int64 realX, ROCCC_int64 imagX,
          ROCCC_int64 realY, ROCCC_int64 imagY,
          ROCCC_int64 realOmega, ROCCC_int64 imagOmega,
          ROCCC_int64& A0, ROCCC_int64& A1, ROCCC_int64& A2, ROCCC_int64& A3)
{
  A0 = realX + (realOmega * realY) - (imagOmega * imagY) ;
  A1 = imagX + (realOmega * imagY) + (imagOmega * realY) ;
  A2 = realX - (realOmega * realY) + (imagOmega * imagY) ;
  A3 = imagX - (realOmega * imagY) - (imagOmega * realY) ;
}
