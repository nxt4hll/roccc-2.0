// This module calculates the Coulombic forces between two atoms.
//  Each atom consists of a position on a 3-Dimensional grid as well
//  as a charge, all of which are represented with floating point numbers.
//  The outputs are the forces in the directional components.

void CoulombicForce(float atomOneX, float atomOneY, float atomOneZ,
                    float atomOneCharge,
                    float atomTwoX, float atomTwoY, float atomTwoZ,
                    float atomTwoCharge,
                    float tableLookup,
                    float& forceX, float& forceY, float& forceZ)
{
  float differenceX ;
  float differenceY ;
  float differenceZ ;

  float distanceXSquared ;
  float distanceYSquared ;
  float distanceZSquared ;

  float radiusSquared ;

  float vcoul ;
  float rinv ;
  float rinvsq ;
  
  differenceX = atomOneX - atomTwoX ;
  differenceY = atomOneY - atomTwoY ;
  differenceZ = atomOneZ - atomTwoZ ;

  distanceXSquared = differenceX * differenceX ;
  distanceYSquared = differenceY * differenceY ;
  distanceZSquared = differenceZ * differenceZ ;

  radiusSquared = distanceXSquared + distanceYSquared + distanceZSquared ;

  rinv = (tableLookup * ((radiusSquared * tableLookup) * tableLookup)) ;

  vcoul = atomOneCharge * atomTwoCharge * rinv ;
  rinvsq = rinv * rinv ;

  forceX = vcoul * rinvsq * differenceX ;
  forceY = vcoul * rinvsq * differenceY ;
  forceZ = vcoul * rinvsq * differenceZ ;
}

