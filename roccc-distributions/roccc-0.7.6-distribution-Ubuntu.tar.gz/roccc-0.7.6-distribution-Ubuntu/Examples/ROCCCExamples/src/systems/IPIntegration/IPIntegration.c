// This example shows how to incorporate an external IP.  The IP core used
//  here is a multiply accumulate core that keeps a running total internally
//  and is reset by asserting the "bypass" signal, which this code does once
//  at the beginning of execution.

#include "roccc-library.h"

void IPIntegration(int* A, int N, int& finalValue)
{
  int i ;
  int currentSum ;
  int bypass ;

  for (i = 0 ; i < N ; i+=2)
  {
    if (i == 0)
    {
      bypass = 1 ;
    }
    else
    {
      bypass = 0 ;
    }
    MultiplyAccumulateWrapper(bypass, A[i], A[i+1], currentSum) ;
    finalValue = currentSum ;
  }
}
