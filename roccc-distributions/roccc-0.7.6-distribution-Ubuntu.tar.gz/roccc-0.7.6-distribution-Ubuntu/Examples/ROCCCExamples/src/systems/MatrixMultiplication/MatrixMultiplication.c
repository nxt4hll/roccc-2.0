// This code performs matrix multiplication between two square 2-D arrays.
//  The length of each side of the array is passed in as the scalar "length."

void MatrixMultiplication(int** A, int** B, int length, int** C)
{ 
	int i ;
	int j ;
	int k ;
	int currentSum ;

	for(i = 0 ; i < length ; ++i)
	{
	  for (j = 0 ; j < length ; ++j)
	  {
	    for (k = 0 ; k < length ; ++k)
	    {
	      if (k == 0)
	      {
		currentSum = 0 ;
	      }
	      currentSum += A[i][k] * B[k][j] ;
	      C[i][j] = currentSum ;
	    }
	  }
	}
}
