
#include "roccc-library.h"

void TCSESystem()
{
  int A[100][100] ;
  
  int i ;
  int j ;

  int maxCol1 ;
  int maxCol2 ;
  int maxCol3 ;

  int finalOutput ;

  for (i = 0 ; i < 100 ; ++i)
  {
    for (j = 0 ; j < 100 ; ++j)
    {
      MAX(A[i][j], A[i][j+1], A[i][j+2], maxCol1) ;
      MAX(A[i+1][j], A[i+1][j+1], A[i+1][j+2], maxCol2) ;
      MAX(A[i+2][j], A[i+2][j+1], A[i+2][j+2], maxCol3) ;

      // The maximum of all the three columns
      MAX(maxCol1, maxCol2, maxCol3, finalOutput) ;
    }
  }

}
