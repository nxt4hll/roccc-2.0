/*
  This example requires the MAX component and shows the capabilites of 
   if statements in ROCCC 2.0.
*/

#include "roccc-library.h"

void ComplexIfSystem()
{
  int A[100] ;
  int B[100] ;
  int i ;
  int temp ;
  int temp2 ;
  
  for (i = 0 ; i < 100 ; ++i)
  {
    if (A[i] != A[i+1])
    {
      temp = A[i+2] ;
      temp = temp + 5 ;
      temp = (temp2 / 15) + temp ;
    }
    else
    {
      if (A[i+1] == 15)
      {
	MAX(A[i], A[i+1], A[i+2], temp2) ;
      }
      else
      {
	MAX(A[i+1], A[i+2], A[i], temp2) ;
      }
      temp = temp2 * 15 ;
    }
    B[i] = temp2 + temp ;
  }
}
